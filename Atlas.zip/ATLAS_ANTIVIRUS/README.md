# 🛡️ ATLAS ANTI-VIRUS

![Version](https://img.shields.io/badge/version-1.0.0-red?style=for-the-badge)
![Python](https://img.shields.io/badge/python-3.7+-blue?style=for-the-badge)
![License](https://img.shields.io/badge/license-MIT-green?style=for-the-badge)
![Status](https://img.shields.io/badge/status-active-success?style=for-the-badge)

**ATLAS ANTI-VIRUS** est un antivirus Python open source basé sur la détection par signature de hash MD5/SHA256 et nom de fichier. Simple, efficace et entièrement transparent.

[![Discord](https://img.shields.io/discord/VOTRE_SERVER_ID?color=7289da&label=Discord&logo=discord&logoColor=white)](https://discord.gg/8UwgMWSX7J)

---

## ✨ Fonctionnalités

- 🔍 **Double détection** : Hash MD5/SHA256 + Nom de fichier
- ⚡ **Scan rapide** : Scan complet du PC ou dossier personnalisé
- 🗄️ **Base de données simple** : Fichier JSON facile à modifier
- 🎯 **Suppression automatique** : Nettoyage en un clic
- 🖥️ **Interface intuitive** : Tkinter avec design ATLAS (noir/rouge/gris)
- 📊 **Logs détaillés** : Suivi en temps réel avec code couleur
- 🔒 **100% Open Source** : Code transparent et auditable
- 💾 **Aucune dépendance** : Seulement Python standard library
- 🌐 **Hors ligne** : Aucune connexion Internet requise
- 🛡️ **Zéro tracking** : Aucune collecte de données

---

## 📥 Installation

### Prérequis
- Python 3.7 ou supérieur
- Tkinter (généralement inclus avec Python)

### Installation rapide

```bash
# Cloner le repository
git clone https://github.com/Hydra356/atlas-antivirus.git
cd atlas-antivirus

# Lancer l'antivirus
python atlas_antivirus.py
```

**Aucune dépendance externe à installer !** Tout est inclus avec Python.

---

## 🚀 Utilisation

### Lancer ATLAS

```bash
python atlas_antivirus.py
```

### Interface

1. **SCANNER LE PC** - Lance un scan complet du système
2. **SCANNER UN DOSSIER** - Choisir un dossier spécifique
3. **ARRÊTER** - Arrête le scan en cours
4. **SUPPRIMER LES MENACES** - Supprime tous les fichiers malveillants détectés

### Processus de scan

1. Cliquez sur "SCANNER LE PC" ou "SCANNER UN DOSSIER"
2. L'antivirus analyse tous les fichiers et calcule leurs hash
3. Les menaces sont affichées en rouge dans le journal
4. Une fois le scan terminé, cliquez sur "SUPPRIMER LES MENACES"

---

## 🗄️ Base de données

La base de données (`database/virus_db.json`) est un fichier JSON simple :

```json
{
  "version": "1.0.0",
  "md5": [
    "44d88612fea8a8f36de82e1278abb02f",
    "098f6bcd4621d373cade4e832627b4f6"
  ],
  "sha256": [
    "6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b"
  ],
  "names": [
    "virus.exe",
    "trojan",
    "malware.dll"
  ]
}
```

### Ajouter des signatures

**Ajouter un hash MD5/SHA256 :**
```json
"md5": [
  "VOTRE_HASH_ICI",
  "44d88612fea8a8f36de82e1278abb02f"
]
```

**Ajouter un nom de fichier suspect :**
```json
"names": [
  "nouveau_virus.exe",
  "trojan"
]
```

---

## 🔍 Comment obtenir des hash de virus

### Sites recommandés

- [VirusTotal](https://www.virustotal.com/) - Base de données massive
- [MalwareBazaar](https://bazaar.abuse.ch/) - Échantillons de malware
- [Hybrid Analysis](https://www.hybrid-analysis.com/) - Analyse comportementale
- [Any.Run](https://any.run/) - Sandbox interactive

### Calculer un hash localement

**Windows (PowerShell) :**
```powershell
Get-FileHash -Algorithm MD5 fichier.exe
Get-FileHash -Algorithm SHA256 fichier.exe
```

**Linux/Mac :**
```bash
md5sum fichier.exe
sha256sum fichier.exe
```

---

## 🛡️ Sécurité

- ✅ **100% Open Source** - Code entièrement auditable
- ✅ **Aucun Malware** - Pas de virus, ransomware, spyware, etc.
- ✅ **Zéro Collecte** - Aucune donnée personnelle collectée
- ✅ **Pas de Connexion** - Fonctionne 100% hors ligne
- ✅ **Aucune Backdoor** - Pas d'accès caché
- ✅ **Gratuit à Jamais** - Pas d'abonnement, pas de premium

---

## 📊 Architecture

```
ATLAS_ANTIVIRUS/
├── atlas_antivirus.py          # Script principal
├── index.html                   # Site web de présentation
├── hydra_profile.png            # Photo de profil
└── database/
    └── virus_db.json            # Base de données de signatures
```

### Technologies utilisées

- **Python 3.7+** - Langage principal
- **Tkinter** - Interface graphique
- **hashlib** - Calcul de hash MD5/SHA256
- **json** - Gestion de la base de données
- **threading** - Scan en arrière-plan

---

## 🎨 Captures d'écran

*Ajoutez vos captures d'écran ici*

---

## 🤝 Contribution

Les contributions sont les bienvenues ! 

1. Fork le projet
2. Créez votre branche (`git checkout -b feature/AmazingFeature`)
3. Commit vos changements (`git commit -m 'Add some AmazingFeature'`)
4. Push vers la branche (`git push origin feature/AmazingFeature`)
5. Ouvrez une Pull Request

---

## 💰 Soutenir le projet

Si vous appréciez ATLAS ANTI-VIRUS, vous pouvez soutenir le développement :

**Bitcoin (BTC)**
```
bc1pvn83qzx9ufy5vcav7vnyjr442snhrws23t89ppr2hfvdzslxccnq2jh0cm
```

**Ethereum / Litecoin**
```
0x707bb59EBB15c64A80691d925682dd4F29F023Ad
```

**Solana (SOL)**
```
7m8JSVaFF4HHN8ecEB6vEhQtEKsJwqsgxWGsPyEspL2p
```

---

## 📞 Contact & Communauté

- 💬 **Discord** : [Rejoindre le serveur](https://discord.gg/8UwgMWSX7J)
- 🔗 **guns.lol** : [hydraaaaa](https://guns.lol/hydraaaaa)
- 🐙 **GitHub** : [@Hydra356](https://github.com/Hydra356)

---

## ⚠️ Avertissements

- **Pas de détection en temps réel** : Cet antivirus scanne uniquement à la demande
- **Détection par signature uniquement** : Ne détecte pas les malwares inconnus
- **Suppression irréversible** : Les fichiers supprimés ne vont PAS dans la corbeille
- **Base de données manuelle** : Vous devez ajouter les signatures manuellement

---

## 📝 Licence

Ce projet est sous licence MIT. Voir le fichier [LICENSE](LICENSE) pour plus de détails.

---

## 👤 Auteur

**ヒドラ (Hydra)**
- Lead Developer

---

## 🙏 Remerciements

Merci à tous ceux qui contribuent à rendre le web plus sûr !

---

<div align="center">

**ATLAS ANTI-VIRUS** - Protection simple et efficace

Made with ❤️ by [Hydra](https://github.com/Hydra356)

⭐ Si vous aimez ce projet, donnez-lui une étoile !

</div>
