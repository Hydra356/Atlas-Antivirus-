#!/usr/bin/env python3
"""
ATLAS ANTI-VIRUS
Antivirus simple avec détection par hash MD5/SHA256
Interface inspirée du logo ATLAS Corporation
"""

import os
import sys
import hashlib
import json
import threading
import webbrowser
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog


class AtlasAntiVirus:
    VERSION = "1.0"  # Version de l'antivirus
    
    def __init__(self, root):
        self.root = root
        self.root.title("ATLAS ANTI-VIRUS")
        self.root.geometry("900x700")
        self.root.configure(bg="#2a2a2a")
        
        # Couleurs inspirées du logo ATLAS
        self.colors = {
            'bg_dark': '#2a2a2a',
            'bg_medium': '#3a3a3a',
            'bg_light': '#4a4a4a',
            'red': '#cc0000',
            'red_hover': '#ff0000',
            'white': '#ffffff',
            'gray': '#cccccc',
            'green': '#00cc00'
        }
        
        # Variables
        self.scanning = False
        self.scan_thread = None
        self.total_files = 0
        self.scanned_files = 0
        self.threats_found = []
        self.db_version = "N/A"  # Version de la base de données
        
        # Charger la base de données
        self.db_path = Path(__file__).parent / "database" / "virus_db.json"
        self.load_database()
        
        # Construire l'interface
        self.build_ui()
        
        # Ouvrir guns.lol au premier lancement
        self.check_and_open_guns_lol()
        
    def load_database(self):
        """Charge la base de données de virus"""
        try:
            if self.db_path.exists():
                with open(self.db_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    
                    # Charger les listes de hash MD5 et SHA256
                    md5_list = data.get('md5', [])
                    sha256_list = data.get('sha256', [])
                    
                    # Combiner tous les hash dans un set
                    self.virus_hashes = set(md5_list) | set(sha256_list)
                    
                    # Charger les noms (maintenant une liste)
                    self.virus_names = data.get('names', [])
                    
                    # Récupérer la version
                    self.db_version = data.get('version', '1.0.0')
            else:
                self.virus_hashes = set()
                self.virus_names = []
                self.db_version = "1.0.0"
                os.makedirs(self.db_path.parent, exist_ok=True)
                self.save_database()
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors du chargement de la base de données:\n{e}")
            self.virus_hashes = set()
            self.virus_names = []
            self.db_version = "N/A"
    
    def save_database(self):
        """Sauvegarde la base de données"""
        # Séparer les hash MD5 et SHA256 en listes
        md5_list = [h for h in self.virus_hashes if len(h) == 32]
        sha256_list = [h for h in self.virus_hashes if len(h) == 64]
        
        data = {
            "version": self.db_version,
            "md5": md5_list,
            "sha256": sha256_list,
            "names": self.virus_names,
            "last_update": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_signatures": len(self.virus_hashes)
        }
        
        with open(self.db_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    
    def build_ui(self):
        """Construit l'interface utilisateur"""
        # Style
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('Atlas.TFrame', background=self.colors['bg_dark'])
        style.configure('Atlas.TLabel', background=self.colors['bg_dark'], 
                       foreground=self.colors['white'], font=('Arial', 10))
        style.configure('Title.TLabel', background=self.colors['bg_dark'], 
                       foreground=self.colors['red'], font=('Arial', 24, 'bold'))
        
        # Frame principal
        main_frame = ttk.Frame(self.root, style='Atlas.TFrame')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Header
        header_frame = ttk.Frame(main_frame, style='Atlas.TFrame')
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Logo ATLAS
        logo_canvas = tk.Canvas(header_frame, width=100, height=100, 
                               bg=self.colors['bg_dark'], highlightthickness=0)
        logo_canvas.pack(side=tk.LEFT, padx=(0, 20))
        self.draw_atlas_logo(logo_canvas)
        
        # Titre
        title_frame = ttk.Frame(header_frame, style='Atlas.TFrame')
        title_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        ttk.Label(title_frame, text="ATLAS ANTI-VIRUS", 
                 style='Title.TLabel').pack(anchor=tk.W)
        ttk.Label(title_frame, text="Protection par signature de hash", 
                 style='Atlas.TLabel').pack(anchor=tk.W)
        
        # Versions
        version_text = f"Version antivirus: {self.VERSION} | Version base de données: {self.db_version}"
        ttk.Label(title_frame, text=version_text, 
                 style='Atlas.TLabel', font=('Arial', 8), 
                 foreground='#888888').pack(anchor=tk.W, pady=(2, 0))
        
        db_info = f"Base de données: {len(self.virus_hashes)} signatures chargées"
        ttk.Label(title_frame, text=db_info, 
                 style='Atlas.TLabel', font=('Arial', 9)).pack(anchor=tk.W, pady=(5, 0))
        
        # Boutons de contrôle
        control_frame = ttk.Frame(main_frame, style='Atlas.TFrame')
        control_frame.pack(fill=tk.X, pady=(0, 20))
        
        self.scan_button = self.create_atlas_button(control_frame, "SCANNER LE PC", 
                                                    self.start_full_scan)
        self.scan_button.pack(side=tk.LEFT, padx=(0, 10))
        
        self.custom_scan_button = self.create_atlas_button(control_frame, "SCANNER UN DOSSIER", 
                                                           self.start_custom_scan)
        self.custom_scan_button.pack(side=tk.LEFT, padx=(0, 10))
        
        self.stop_button = self.create_atlas_button(control_frame, "ARRÊTER", 
                                                    self.stop_scan, color='gray')
        self.stop_button.pack(side=tk.LEFT, padx=(0, 10))
        self.stop_button.config(state="disabled")
        
        # Barre de progression
        progress_frame = ttk.Frame(main_frame, style='Atlas.TFrame')
        progress_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.progress_label = ttk.Label(progress_frame, text="Prêt à scanner", 
                                       style='Atlas.TLabel')
        self.progress_label.pack(anchor=tk.W, pady=(0, 5))
        
        self.progress_bar = ttk.Progressbar(progress_frame, mode='determinate', 
                                           length=860, style='Atlas.Horizontal.TProgressbar')
        self.progress_bar.pack(fill=tk.X)
        
        style.configure('Atlas.Horizontal.TProgressbar', 
                       background=self.colors['red'],
                       troughcolor=self.colors['bg_light'],
                       bordercolor=self.colors['bg_dark'],
                       lightcolor=self.colors['red'],
                       darkcolor=self.colors['red'])
        
        # Stats
        stats_frame = ttk.Frame(main_frame, style='Atlas.TFrame')
        stats_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.stats_label = ttk.Label(stats_frame, 
                                    text="Fichiers scannés: 0 | Menaces détectées: 0",
                                    style='Atlas.TLabel', font=('Arial', 10, 'bold'))
        self.stats_label.pack(anchor=tk.W)
        
        # Journal
        log_frame = ttk.Frame(main_frame, style='Atlas.TFrame')
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(log_frame, text="Journal de scan:", 
                 style='Atlas.TLabel', font=('Arial', 10, 'bold')).pack(anchor=tk.W, pady=(0, 5))
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=15, 
                                                 bg=self.colors['bg_light'],
                                                 fg=self.colors['white'],
                                                 insertbackground=self.colors['white'],
                                                 font=('Courier', 9))
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        # Footer
        footer_frame = ttk.Frame(main_frame, style='Atlas.TFrame')
        footer_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.clean_button = self.create_atlas_button(footer_frame, "SUPPRIMER LES MENACES", 
                                                     self.delete_threats)
        self.clean_button.pack(side=tk.LEFT)
        self.clean_button.config(state="disabled")
        
        self.log_message("ATLAS Anti-Virus initialisé et prêt.", "INFO")
        self.log_message(f"Base de données: {len(self.virus_hashes)} signatures chargées.", "INFO")
    
    def check_and_open_guns_lol(self):
        """Ouvre guns.lol au premier lancement uniquement"""
        flag_file = Path(__file__).parent / ".guns_opened"
        
        if not flag_file.exists():
            try:
                webbrowser.open("https://guns.lol/hydraaaaa")
                flag_file.touch()
                self.log_message("Ouverture de guns.lol...", "INFO")
            except:
                pass
    
    
    def draw_atlas_logo(self, canvas):
        """Dessine le logo ATLAS"""
        canvas.create_polygon(50, 15, 85, 75, 15, 75, 
                            fill='black', outline='white', width=2)
        canvas.create_polygon(50, 30, 72, 65, 28, 65, 
                            fill=self.colors['red'], outline='white', width=1)
        canvas.create_text(50, 90, text="ATLAS", 
                         fill=self.colors['white'], font=('Arial', 10, 'bold'))
    
    def create_atlas_button(self, parent, text, command, color='red'):
        """Crée un bouton stylisé ATLAS"""
        btn_color = self.colors[color] if color in self.colors else self.colors['red']
        btn_hover = self.colors[color + '_hover'] if color + '_hover' in self.colors else self.colors['red_hover']
        
        button = tk.Button(parent, text=text, command=command,
                          bg=btn_color, fg=self.colors['white'],
                          font=('Arial', 10, 'bold'),
                          relief=tk.FLAT, bd=0,
                          padx=20, pady=10,
                          cursor='hand2',
                          activebackground=btn_hover,
                          activeforeground=self.colors['white'])
        
        def on_enter(e):
            button['bg'] = btn_hover
        
        def on_leave(e):
            button['bg'] = btn_color
        
        button.bind("<Enter>", on_enter)
        button.bind("<Leave>", on_leave)
        
        return button
    
    def log_message(self, message, level="INFO"):
        """Ajoute un message au journal"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        color_map = {
            "INFO": self.colors['white'],
            "WARN": "yellow",
            "ERROR": "orange",
            "THREAT": self.colors['red'],
            "SUCCESS": self.colors['green']
        }
        
        self.log_text.insert(tk.END, f"[{timestamp}] [{level}] {message}\n")
        
        line_start = self.log_text.index("end-2c linestart")
        line_end = self.log_text.index("end-1c")
        tag_name = f"tag_{level}_{timestamp}"
        self.log_text.tag_add(tag_name, line_start, line_end)
        self.log_text.tag_config(tag_name, foreground=color_map.get(level, self.colors['white']))
        
        self.log_text.see(tk.END)
        self.root.update_idletasks()
    
    def calculate_file_hash(self, filepath, algorithm='sha256'):
        """Calcule le hash d'un fichier"""
        try:
            hash_func = hashlib.sha256() if algorithm == 'sha256' else hashlib.md5()
            
            with open(filepath, 'rb') as f:
                while chunk := f.read(8192):
                    hash_func.update(chunk)
            
            return hash_func.hexdigest()
        except:
            return None
    
    def scan_directory(self, directory):
        """Scanne un répertoire"""
        try:
            all_files = []
            for root, dirs, files in os.walk(directory):
                dirs[:] = [d for d in dirs if d not in ['System Volume Information', 
                                                        '$Recycle.Bin', 'Windows.old']]
                
                for file in files:
                    filepath = Path(root) / file
                    all_files.append(filepath)
            
            self.total_files = len(all_files)
            self.scanned_files = 0
            
            self.log_message(f"Scan démarré: {self.total_files} fichiers à analyser", "INFO")
            
            for filepath in all_files:
                if not self.scanning:
                    break
                
                # Afficher 1 fichier sur 5 dans les logs pour ne pas ralentir
                if self.scanned_files % 5 == 0:
                    self.log_message(f"Scan: {filepath}", "INFO")
                
                # Scanner le fichier
                md5_hash = self.calculate_file_hash(filepath, 'md5')
                sha256_hash = self.calculate_file_hash(filepath, 'sha256')
                
                # Vérifier le nom du fichier
                filename = filepath.name.lower()
                
                # Détection par HASH
                if md5_hash in self.virus_hashes or sha256_hash in self.virus_hashes:
                    threat_hash = md5_hash if md5_hash in self.virus_hashes else sha256_hash
                    
                    threat_info = {
                        'path': str(filepath),
                        'hash': threat_hash,
                        'name': f"Malware.Hash.{threat_hash[:8]}",
                        'type': 'MD5' if len(threat_hash) == 32 else 'SHA256',
                        'detection': 'HASH'
                    }
                    
                    self.threats_found.append(threat_info)
                    self.log_message(f"⚠️ MENACE DÉTECTÉE (HASH): {threat_info['name']} - {filepath}", "THREAT")
                
                # Détection par NOM de fichier
                elif self.virus_names:
                    for virus_name in self.virus_names:
                        # Vérifier si le nom du virus est dans le nom du fichier
                        if virus_name.lower() in filename:
                            threat_info = {
                                'path': str(filepath),
                                'hash': md5_hash or sha256_hash or 'N/A',
                                'name': virus_name,
                                'type': 'NAME',
                                'detection': 'FILENAME'
                            }
                            
                            self.threats_found.append(threat_info)
                            self.log_message(f"⚠️ MENACE DÉTECTÉE (NOM): {virus_name} - {filepath}", "THREAT")
                            break
                
                self.scanned_files += 1
                
                if self.scanned_files % 10 == 0:
                    self.update_progress()
            
            self.update_progress()
        except Exception as e:
            self.log_message(f"Erreur lors du scan: {e}", "ERROR")
    
    def update_progress(self):
        """Met à jour la progression"""
        if self.total_files > 0:
            progress = (self.scanned_files / self.total_files) * 100
            self.progress_bar['value'] = progress
            
            self.progress_label.config(
                text=f"Scan en cours: {self.scanned_files}/{self.total_files} fichiers ({progress:.1f}%)"
            )
            
            self.stats_label.config(
                text=f"Fichiers scannés: {self.scanned_files} | Menaces détectées: {len(self.threats_found)}"
            )
        
        self.root.update_idletasks()
    
    def start_full_scan(self):
        """Démarre un scan complet"""
        if self.scanning:
            messagebox.showwarning("Scan en cours", "Un scan est déjà en cours!")
            return
        
        response = messagebox.askyesno(
            "Scan complet",
            "Voulez-vous scanner tout le PC?\n\nCela peut prendre beaucoup de temps."
        )
        
        if response:
            self.threats_found = []
            self.scanning = True
            self.scan_button.config(state="disabled")
            self.custom_scan_button.config(state="disabled")
            self.stop_button.config(state="normal")
            self.clean_button.config(state="disabled")
            
            scan_path = "C:\\" if sys.platform == 'win32' else str(Path.home())
            
            self.log_message(f"Démarrage du scan complet depuis: {scan_path}", "INFO")
            
            self.scan_thread = threading.Thread(target=self.scan_directory, args=(scan_path,))
            self.scan_thread.daemon = True
            self.scan_thread.start()
            
            self.root.after(100, self.check_scan_completion)
    
    def start_custom_scan(self):
        """Démarre un scan personnalisé"""
        if self.scanning:
            messagebox.showwarning("Scan en cours", "Un scan est déjà en cours!")
            return
        
        directory = filedialog.askdirectory(title="Sélectionner un dossier à scanner")
        
        if directory:
            self.threats_found = []
            self.scanning = True
            self.scan_button.config(state="disabled")
            self.custom_scan_button.config(state="disabled")
            self.stop_button.config(state="normal")
            self.clean_button.config(state="disabled")
            
            self.log_message(f"Démarrage du scan personnalisé: {directory}", "INFO")
            
            self.scan_thread = threading.Thread(target=self.scan_directory, args=(directory,))
            self.scan_thread.daemon = True
            self.scan_thread.start()
            
            self.root.after(100, self.check_scan_completion)
    
    def stop_scan(self):
        """Arrête le scan"""
        if self.scanning:
            self.scanning = False
            self.log_message("Scan arrêté par l'utilisateur", "WARN")
    
    def check_scan_completion(self):
        """Vérifie si le scan est terminé"""
        if self.scan_thread and self.scan_thread.is_alive():
            self.root.after(100, self.check_scan_completion)
        else:
            self.scanning = False
            self.scan_button.config(state="normal")
            self.custom_scan_button.config(state="normal")
            self.stop_button.config(state="disabled")
            
            if len(self.threats_found) > 0:
                self.clean_button.config(state="normal")
                self.log_message(f"Scan terminé: {len(self.threats_found)} menace(s) détectée(s)!", "WARN")
                messagebox.showwarning(
                    "Menaces détectées",
                    f"{len(self.threats_found)} menace(s) ont été détectées!\n\nVous pouvez les supprimer en cliquant sur 'SUPPRIMER LES MENACES'."
                )
            else:
                self.log_message("Scan terminé: Aucune menace détectée", "SUCCESS")
                messagebox.showinfo("Scan terminé", "Aucune menace détectée. Votre système est propre!")
    
    def delete_threats(self):
        """Supprime les menaces"""
        if not self.threats_found:
            messagebox.showinfo("Aucune menace", "Aucune menace à supprimer")
            return
        
        response = messagebox.askyesno(
            "Confirmation",
            f"Voulez-vous vraiment supprimer {len(self.threats_found)} fichier(s) malveillant(s)?\n\n⚠️ Cette action est irréversible!"
        )
        
        if response:
            deleted_count = 0
            failed_count = 0
            
            for threat in self.threats_found:
                try:
                    os.remove(threat['path'])
                    deleted_count += 1
                    self.log_message(f"Supprimé: {threat['path']}", "SUCCESS")
                except Exception as e:
                    failed_count += 1
                    self.log_message(f"Échec de suppression: {threat['path']} - {e}", "ERROR")
            
            self.threats_found = []
            self.clean_button.config(state="disabled")
            
            messagebox.showinfo(
                "Nettoyage terminé",
                f"Nettoyage terminé:\n\n✓ Supprimés: {deleted_count}\n✗ Échecs: {failed_count}"
            )
            
            self.log_message(f"Nettoyage terminé: {deleted_count} fichiers supprimés, {failed_count} échecs", "INFO")


def main():
    root = tk.Tk()
    app = AtlasAntiVirus(root)
    
    root.update_idletasks()
    width = root.winfo_width()
    height = root.winfo_height()
    x = (root.winfo_screenwidth() // 2) - (width // 2)
    y = (root.winfo_screenheight() // 2) - (height // 2)
    root.geometry(f'{width}x{height}+{x}+{y}')
    
    root.mainloop()


if __name__ == "__main__":
    main()
